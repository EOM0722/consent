from flask import Flask, request, jsonify, render_template, url_for
import os
import base64
from datetime import datetime
from flask_cors import CORS

app = Flask(__name__,
   static_url_path='',  # 정적 파일 경로 설정
   static_folder='static',  # static 폴더 위치 지정
   template_folder='templates'  # templates 폴더 위치 지정
)
CORS(app)

# WSL 환경에서의 경로 설정
UPLOAD_FOLDER = '/mnt/h/consent/sign'
if not os.path.exists(UPLOAD_FOLDER):
   os.makedirs(UPLOAD_FOLDER, exist_ok=True)

@app.route('/')
def index():
    return render_template('index.html')  # 기증동의서 작성

@app.route('/health')
def health():
    return render_template('projects.html')  # 사과나무건강증진센터

@app.route('/biobank')
def biobank():
    return render_template('contact.html')  # 사과나무구강유래물은행

@app.route('/save-signature', methods=['POST'])
def save_signature():
   try:
       data = request.json
       signature_data = data['signature'].split(',')[1]
       name = data['name']
       
       timestamp = datetime.now().strftime('%Y%m%d_%H%M%S')
       filename = f"signature_{name}_{timestamp}.png"
       filepath = os.path.join(UPLOAD_FOLDER, filename)
       
       with open(filepath, 'wb') as f:
           f.write(base64.b64decode(signature_data))
       
       print(f"Successfully saved signature to: {filepath}")
       return jsonify({'success': True, 'filename': filename})
   
   except Exception as e:
       print(f"Error occurred: {str(e)}")
       return jsonify({'success': False, 'error': str(e)}), 500

@app.route('/test')
def test_path():
   try:
       print(f"Current working directory: {os.getcwd()}")
       print(f"Upload folder path: {UPLOAD_FOLDER}")
       print(f"Upload folder exists: {os.path.exists(UPLOAD_FOLDER)}")
       return jsonify({
           'cwd': os.getcwd(),
           'upload_folder': UPLOAD_FOLDER,
           'exists': os.path.exists(UPLOAD_FOLDER)
       })
   except Exception as e:
       return jsonify({'error': str(e)})

if __name__ == '__main__':
   app.run(port=5000, debug=True)